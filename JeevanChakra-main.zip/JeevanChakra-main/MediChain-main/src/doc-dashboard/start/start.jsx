import React from 'react';
import { SetAvailabilityPage } from './Set-availability';

const StartPage = () => {
    return (
        <div>
            <SetAvailabilityPage/>
        </div>
    );
};

export default StartPage;


