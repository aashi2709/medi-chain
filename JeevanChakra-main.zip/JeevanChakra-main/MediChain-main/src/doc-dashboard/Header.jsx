
import React from "react";

const Header = () => {
  return (
    <div className="header">
      <h1>Bookings</h1>
      <p>See your scheduled events from your calendar events links.</p>
    </div>
  );
};

export default Header;
